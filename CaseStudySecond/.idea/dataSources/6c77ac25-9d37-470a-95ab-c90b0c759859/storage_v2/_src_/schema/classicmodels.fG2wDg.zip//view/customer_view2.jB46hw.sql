create view customer_view2 as
select `classicmodels`.`customers`.`customerName` AS `customerName`,
       `classicmodels`.`customers`.`country`      AS `country`,
       `classicmodels`.`customers`.`creditLimit`  AS `creditLimit`
from `classicmodels`.`customers`
where (`classicmodels`.`customers`.`country` = 'USA');

