create
    definer = root@localhost procedure findId(IN id int(20))
begin
    select customerNumber, customerName, creditLimit from customers where customerNumber = id order by customerName;
end;

